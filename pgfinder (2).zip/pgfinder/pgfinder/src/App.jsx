


import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import Layout from './components/Layout';
import Homem from './components/Homem';
import BookingDetails from './components/BookingDetails';
import Login from './components/Login';
import Signup from './components/Signup';
import Admin from './components/Admin';
import "./App.css";

const getUserData = () => {
  const userDataString = localStorage.getItem('user');
  if (userDataString) {
    try {
      return JSON.parse(userDataString);
    } catch (error) {
      console.error('Error parsing user data:', error);
    }
  }
  return null;
};

const isAuthenticated = () => {
  return !!getUserData();
};

const ProtectedBookingRoute = ({ children }) => {
  const auth = isAuthenticated();

  if (!auth) {
    return <Navigate to="/login" replace />;
  }

  return children ? children : <Outlet />;
};

const AdminRoute = ({ children }) => {
  const userData = getUserData();

  if (!userData || userData.email !== 'yashmittal4949@gmail.com') {
    return <Navigate to="/login" replace />;
  }

  return children ? children : <Outlet />;
};

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Homem />} />
          <Route path="booking/:pgId" element={
            <ProtectedBookingRoute>
              <BookingDetails />
            </ProtectedBookingRoute>
          } />
          <Route path="login" element={<Login />} />
          <Route path="signup" element={<Signup />} />
        </Route>
        <Route path="admin" element={
          <AdminRoute>
            <Admin />
          </AdminRoute>
        } />
      </Routes>
    </Router>
  );
}

export default App;

