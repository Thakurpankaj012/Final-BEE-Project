

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, PlusCircle, Search, Filter, Eye, Trash2, Check, X, Home, BarChart2, PieChart, Menu, Edit, RefreshCw } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart as RePieChart, Pie, Cell, LineChart, Line } from 'recharts';
import axios from 'axios';

const Admin = () => {
  const [activeTab, setActiveTab] = useState('bookings');
  const [bookings, setBookings] = useState([]);
  const [pgs, setPgs] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterOption, setFilterOption] = useState('all');
  const [showAddPgModal, setShowAddPgModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      if (activeTab === 'bookings') {
        await fetchBookings();
      } else {
        await fetchPgs();
      }
    } catch (error) {
      console.error(`Error fetching ${activeTab}:`, error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchBookings = async () => {
    const response = await axios.get('http://localhost:5000/api/bookings');
    setBookings(response.data);
  };

  const fetchPgs = async () => {
    const response = await axios.get('http://localhost:5000/api/pgs');
    setPgs(response.data);
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleFilter = (e) => {
    setFilterOption(e.target.value);
  };

  const handleViewDetails = (item) => {
    setSelectedItem(item);
    setShowViewModal(true);
  };

  const handleEditItem = (item) => {
    setSelectedItem(item);
    setShowEditModal(true);
  };

  const handleDelete = async (id, type) => {
    try {
      if (type === 'booking') {
        await axios.delete(`http://localhost:5000/api/bookings/${id}`);
        await fetchBookings();
      } else {
        await axios.delete(`http://localhost:5000/api/pgs/${id}`);
        await fetchPgs();
      }
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  const handleStatusChange = async (id, newStatus) => {
    try {
      const response = await axios.patch(`http://localhost:5000/api/bookings/${id}`, { status: newStatus });
      if (response.data) {
        await fetchBookings();
        setShowEditModal(false);
      } else {
        console.error('Error updating booking status:', response.data.message);
        alert('Failed to update booking status. Please try again.');
      }
    } catch (error) {
      console.error('Error updating booking status:', error);
      alert('An error occurred while updating the booking status. Please try again.');
    }
  };

  const handleAddPg = async (newPg) => {
    try {
      const formData = new FormData();
      Object.keys(newPg).forEach(key => {
        if (key === 'amenities') {
          formData.append('amenities', JSON.stringify(newPg[key]));
        } else if (key === 'image' && newPg[key] instanceof FileList) {
          formData.append('image', newPg[key][0]);
        } else {
          formData.append(key, newPg[key]);
        }
      });
  
      const response = await axios.post('http://localhost:5000/api/pgs', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
  
      if (response.data) {
        await fetchPgs();
        setShowAddPgModal(false);
      } else {
        throw new Error('Failed to add new PG');
      }
    } catch (error) {
      console.error('Error adding new PG:', error);
      alert(`Failed to add new PG: ${error.message}`);
    }
  };
  
  

  const handleEditPg = async (editedPg) => {
    try {
      const formData = new FormData();
      Object.keys(editedPg).forEach(key => {
        if (key === 'amenities') {
          formData.append('amenities', JSON.stringify(editedPg[key]));
        } else if (key === 'image' && editedPg[key] instanceof File) {
          formData.append('image', editedPg[key]);
        } else {
          formData.append(key, editedPg[key]);
        }
      });

      const response = await axios.patch(`http://localhost:5000/api/pgs/${editedPg._id}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      if (response.data) {
        await fetchPgs();
        setShowEditModal(false);
      } else {
        throw new Error('Failed to edit PG');
      }
    } catch (error) {
      console.error('Error editing PG:', error);
      alert(`Failed to edit PG: ${error.message}`);
    }
  };


  const handlePgStatusChange = async (id, currentStatus) => {
    try {
      const newStatus = currentStatus === 'available' ? 'unavailable' : 'available';
      await axios.patch(`http://localhost:5000/api/pgs/${id}`, { status: newStatus });
      await fetchPgs();
    } catch (error) {
      console.error('Error updating PG status:', error);
    }
  };

  const filteredItems = activeTab === 'bookings' ? bookings : pgs;
  const filteredAndSearchedItems = filteredItems.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
    (filterOption === 'all' || item.status === filterOption)
  );

  
  const bookingStatusData = [
    { name: 'Pending', value: bookings.filter(b => b.status === 'pending').length },
    { name: 'Accepted', value: bookings.filter(b => b.status === 'accepted').length },
    { name: 'Rejected', value: bookings.filter(b => b.status === 'rejected').length },
  ];

  const pgTypeData = [
    { name: 'Single', value: pgs.filter(pg => pg.type === 'Single').length },
    { name: 'Double', value: pgs.filter(pg => pg.type === 'Double').length },
    { name: 'Triple', value: pgs.filter(pg => pg.type === 'Triple').length },
  ];

  const pgPriceData = pgs.map(pg => ({
    name: pg.name,
    price: pg.price,
  }));

  const bookingsByDateData = bookings.reduce((acc, booking) => {
    const date = new Date(booking.date).toLocaleDateString();
    acc[date] = (acc[date] || 0) + 1;
    return acc;
  }, {});

  const bookingsByDateChartData = Object.entries(bookingsByDateData).map(([date, count]) => ({
    date,
    count,
  }));

  const pgAmenitiesData = pgs.reduce((acc, pg) => {
    pg.amenities.forEach(amenity => {
      acc[amenity] = (acc[amenity] || 0) + 1;
    });
    return acc;
  }, {});

  const pgAmenitiesChartData = Object.entries(pgAmenitiesData).map(([amenity, count]) => ({
    amenity,
    count,
  }));

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

  return (
    <div className="flex h-screen bg-gray-100">
      
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ x: -250 }}
            animate={{ x: 0 }}
            exit={{ x: -250 }}
            className="w-64 bg-white shadow-lg z-20"
          >
            <div className="p-4">
              <h2 className="text-2xl font-semibold text-gray-800">Admin Panel</h2>
            </div>
            <nav className="mt-4">
              <a
                href="#"
                className={`flex items-center py-2 px-4 ${activeTab === 'bookings' ? 'bg-blue-500 text-white' : 'text-gray-700 hover:bg-gray-200'}`}
                onClick={() => setActiveTab('bookings')}
              >
                <Users className="mr-2" />
                Bookings
              </a>
              <a
                href="#"
                className={`flex items-center py-2 px-4 ${activeTab === 'pgs' ? 'bg-blue-500 text-white' : 'text-gray-700 hover:bg-gray-200'}`}
                onClick={() => setActiveTab('pgs')}
              >
                <Home className="mr-2" />
                PGs
              </a>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      
      <div className="flex-1 overflow-x-hidden overflow-y-auto">
        <div className="container mx-auto px-6 py-8">
          <div className="flex justify-between items-center mb-8">
            <button
              className="text-gray-500 hover:text-gray-600"
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            >
              <Menu size={24} />
            </button>
            <h3 className="text-3xl font-medium text-gray-700">
              {activeTab === 'bookings' ? 'Bookings' : 'PGs'}
            </h3>
            <button
              className="bg-blue-500 text-white px-4 py-2 rounded-lg shadow hover:bg-blue-600 transition duration-200"
              onClick={fetchData}
            >
              <RefreshCw className="inline-block mr-2" />
              Refresh
            </button>
          </div>
          <div className="mt-8">
           
            <div className="flex flex-col md:flex-row mb-4 space-y-2 md:space-y-0 md:space-x-4">
              <div className="relative flex-grow">
                <input
                  type="text"
                  className="w-full pl-10 pr-4 py-2 rounded-lg shadow focus:outline-none focus:shadow-outline text-gray-600 font-medium"
                  placeholder="Search..."
                  value={searchTerm}
                  onChange={handleSearch}
                />
                <div className="absolute top-0 left-0 inline-flex items-center p-2">
                  <Search className="w-6 h-6 text-gray-400" />
                </div>
              </div>
              <select
                className="pl-4 pr-8 py-2 rounded-lg shadow focus:outline-none focus:shadow-outline text-gray-600 font-medium"
                value={filterOption}
                onChange={handleFilter}
              >
                <option value="all">All</option>
                <option value="pending">Pending</option>
                <option value="accepted">Accepted</option>
                <option value="rejected">Rejected</option>
                {activeTab === 'pgs' && (
                  <>
                    <option value="available">Available</option>
                    <option value="unavailable">Unavailable</option>
                  </>
                )}
              </select>
              {activeTab === 'pgs' && (
                <button
                  className="bg-green-500 text-white px-4 py-2 rounded-lg shadow hover:bg-green-600 transition duration-200"
                  onClick={() => setShowAddPgModal(true)}
                >
                  <PlusCircle className="inline-block mr-2" />
                  Add PG
                </button>
              )}
            </div>

            
            {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
              </div>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-white shadow-md rounded my-6 overflow-x-auto"
              >
                <table className="min-w-max w-full table-auto">
                  <thead>
                    <tr className="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                      <th className="py-3 px-6 text-left">Name</th>
                      <th className="py-3 px-6 text-left">Status</th>
                      <th className="py-3 px-6 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="text-gray-600 text-sm font-light">
                    {filteredAndSearchedItems.map((item) => (
                      <motion.tr
                        key={item._id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="border-b border-gray-200 hover:bg-gray-100"
                      >
                        <td className="py-3 px-6 text-left whitespace-nowrap">
                          <div className="flex items-center">
                            <span className="font-medium">{item.name}</span>
                          </div>
                        </td>
                        <td className="py-3 px-6 text-left">
                          <span className={`bg-${item.status === 'accepted' || item.status === 'available' ? 'green' : item.status === 'rejected' || item.status === 'unavailable' ? 'red' : 'yellow'}-200 text-${item.status === 'accepted' || item.status === 'available' ? 'green' : item.status === 'rejected' || item.status === 'unavailable' ? 'red' : 'yellow'}-600 py-1 px-3 rounded-full text-xs`}>
                            {item.status}
                          </span>
                        </td>
                        <td className="py-3 px-6 text-center">
                          <div className="flex item-center justify-center">
                            <button className="w-4 mr-2 transform hover:text-purple-500 hover:scale-110" onClick={() => handleViewDetails(item)}>
                              <Eye />
                            </button>
                            <button className="w-4 mr-2 transform hover:text-blue-500 hover:scale-110" onClick={() => handleEditItem(item)}>
                              <Edit />
                            </button>
                            <button className="w-4 mr-2 transform hover:text-red-500 hover:scale-110" onClick={() => handleDelete(item._id, activeTab === 'bookings' ? 'booking' : 'pg')}>
                              <Trash2 />
                            </button>
                            {activeTab === 'bookings' && item.status === 'pending' && (
                              <>
                                <button className="w-4 mr-2 transform hover:text-green-500 hover:scale-110" onClick={() => handleStatusChange(item._id, 'accepted')}>
                                  <Check />
                                </button>
                                <button className="w-4 mr-2 transform hover:text-red-500 hover:scale-110" onClick={() => handleStatusChange(item._id, 'rejected')}>
                                  <X />
                                </button>
                              </>
                            )}
                            {activeTab === 'pgs' && (
                              <button className="w-4 mr-2 transform hover:text-purple-500 hover:scale-110" onClick={() => handlePgStatusChange(item._id, item.status)}>
                                {item.status === 'available' ? <X /> : <Check />}
                              </button>
                            )}
                          </div>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </motion.div>
            )}

           
            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="bg-white p-6 rounded-lg shadow-md"
              >
                <h4 className="text-xl font-semibold mb-4">Booking Status</h4>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={bookingStatusData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="bg-white p-6 rounded-lg shadow-md"
              >
                <h4 className="text-xl font-semibold mb-4">PG Types</h4>
                <ResponsiveContainer width="100%" height={300}>
                  <RePieChart>
                    <Pie
                      data={pgTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {pgTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </RePieChart>
                </ResponsiveContainer>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.6 }}
                className="bg-white p-6 rounded-lg shadow-md"
              >
                <h4 className="text-xl font-semibold mb-4">PG Prices</h4>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={pgPriceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="price" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.8 }}
                className="bg-white p-6 rounded-lg shadow-md"
              >
                <h4 className="text-xl font-semibold mb-4">Bookings by Date</h4>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={bookingsByDateChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="count" stroke="#8884d8" />
                  </LineChart>
                </ResponsiveContainer>
              </motion.div>
            </div>
          </div>
        </div>
      </div>

     
      {showViewModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Details</h3>
                <div className="max-h-96 overflow-y-auto">
                  {Object.entries(selectedItem).map(([key, value]) => (
                    <p key={key} className="text-sm text-gray-500 mb-2">
                      <span className="font-medium">{key}: </span>
                      {key === 'idProof' || key === 'image' ? (
                        <img src={`http://localhost:5000/${value}`} alt={key} className="mt-2 max-w-full h-auto" />
                      ) : (
                        typeof value === 'object' ? JSON.stringify(value) : value
                      )}
                    </p>
                  ))}
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  type="button"
                  className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                  onClick={() => setShowViewModal(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      
      {showAddPgModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const newPg = Object.fromEntries(formData.entries());
                newPg.amenities = formData.getAll('amenities');
                handleAddPg(newPg);
              }}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Add New PG</h3>
                  <div className="mb-4">
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                    <input type="text" name="name" id="name" required className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" />
                  </div>
                  <div className="mb-4">
                    <label htmlFor="place" className="block text-sm font-medium text-gray-700">Place</label>
                    <input type="text" name="place" id="place" required className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" />
                  </div>
                  <div className="mb-4">
                    <label htmlFor="owner" className="block text-sm font-medium text-gray-700">Owner</label>
                    <input type="text" name="owner" id="owner" required className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" />
                  </div>
                  <div className="mb-4">
                    <label htmlFor="price" className="block text-sm font-medium text-gray-700">Price</label>
                    <input type="number" name="price" id="price" required className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" />
                  </div>
                  <div className="mb-4">
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone</label>
                    <input type="tel" name="phone" id="phone" required className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" />
                  </div>
                  <div className="mb-4">
                    <label htmlFor="image" className="block text-sm font-medium text-gray-700">Image</label>
                    <input type="file" name="image" id="image" accept="image/*" required className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" />
                  </div>
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700">Amenities</label>
                    <div className="mt-2 space-y-2">
                      <div>
                        <input type="checkbox" id="wifi" name="amenities" value="Wi-Fi" className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded" />
                        <label htmlFor="wifi" className="ml-2 text-sm text-gray-700">Wi-Fi</label>
                      </div>
                      <div>
                        <input type="checkbox" id="ac" name="amenities" value="AC" className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded" />
                        <label htmlFor="ac" className="ml-2 text-sm text-gray-700">AC</label>
                      </div>
                      <div>
                        <input type="checkbox" id="gym" name="amenities" value="Gym" className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded" />
                        <label htmlFor="gym" className="ml-2 text-sm text-gray-700">Gym</label>
                      </div>
                      <div>
                        <input type="checkbox" id="laundry" name="amenities" value="Laundry" className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded" />
                        <label htmlFor="laundry" className="ml-2 text-sm text-gray-700">Laundry</label>
                      </div>
                      <div>
                        <input type="checkbox" id="pool" name="amenities" value="Pool" className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded" />
                        <label htmlFor="pool" className="ml-2 text-sm text-gray-700">Pool</label>
                      </div>
                      <div>
                        <input type="checkbox" id="garden" name="amenities" value="Garden" className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded" />
                        <label htmlFor="garden" className="ml-2 text-sm text-gray-700">Garden</label>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    Add PG
                  </button>
                  <button
                    type="button"
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                    onClick={() => setShowAddPgModal(false)}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      
      {showEditModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const editedItem = Object.fromEntries(formData.entries());
                editedItem.amenities = formData.getAll('amenities');
                editedItem._id = selectedItem._id; 
                if (activeTab === 'bookings') {
                  handleStatusChange(selectedItem._id, editedItem.status);
                } else {
                  handleEditPg(editedItem);
                }
              }}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Edit {activeTab === 'bookings' ? 'Booking' : 'PG'}</h3>
                  {Object.entries(selectedItem).map(([key, value]) => {
                    if (key === '_id' || key === '__v' || key === 'createdAt' || key === 'updatedAt') return null;
                    if (key === 'amenities' && Array.isArray(value)) {
                      return (
                        <div key={key} className="mb-4">
                          <label className="block text-sm font-medium text-gray-700">Amenities</label>
                          <div className="mt-2 space-y-2">
                            {['Wi-Fi', 'AC', 'Gym', 'Laundry', 'Pool', 'Garden'].map((amenity) => (
                              <div key={amenity}>
                                <input
                                  type="checkbox"
                                  id={amenity.toLowerCase()}
                                  name="amenities"
                                  value={amenity}
                                  defaultChecked={value.includes(amenity)}
                                  className="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded"
                                />
                                <label htmlFor={amenity.toLowerCase()} className="ml-2 text-sm text-gray-700">{amenity}</label>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    }
                    return (
                      <div key={key} className="mb-4">
                        <label htmlFor={key} className="block text-sm font-medium text-gray-700">{key}</label>
                        {key === 'image' || key === 'idProof' ? (
                          <div>
                            <img src={`http://localhost:5000/${value}`} alt={key} className="mt-2 max-w-full h-auto mb-2" />
                            <input
                              type="file"
                              name={key}
                              id={key}
                              className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                            />
                          </div>
                        ) : key === 'status' ? (
                          <select
                            name={key}
                            id={key}
                            defaultValue={value}
                            className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                          >
                            <option value="pending">Pending</option>
                            <option value="accepted">Accepted</option>
                            <option value="rejected">Rejected</option>
                            {activeTab === 'pgs' && (
                              <>
                                <option value="available">Available</option>
                                <option value="unavailable">Unavailable</option>
                              </>
                            )}
                          </select>
                        ) : (
                          <input
                            type={key === 'price' ? 'number' : 'text'}
                            name={key}
                            id={key}
                            defaultValue={value}
                            className="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                          />
                        )}
                      </div>
                    );
                  })}
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    Save Changes
                  </button>
                  <button
                    type="button"
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                    onClick={() => setShowEditModal(false)}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Admin;

