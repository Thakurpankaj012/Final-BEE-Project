import React, { useState, useEffect, useRef } from 'react'
import { motion, useScroll, useTransform, useSpring, useInView } from 'framer-motion'
import { Menu, X, Search, Check, ChevronLeft, ChevronRight, Star, Phone, MapPin, Home, DollarSign, Users, Coffee } from 'lucide-react'
import { Link } from 'react-router-dom'

function Navbar() {
    const [isMenuOpen, setIsMenuOpen] = useState(false)
    const scrollRef = useRef(null)
    const { scrollYProgress } = useScroll({
        target: scrollRef,
        offset: ["start start", "end end"]
      })
    const smoothProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 })
    const aboutRef = useRef(null)
  const isAboutInView = useInView(aboutRef, { once: true })
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');

  useEffect(() => {
    // Check for stored login data on component mount
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setIsLoggedIn(true);
      setUsername(localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')).name : ''); // Handle potential missing username in localStorage
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setIsLoggedIn(false);
    setUsername('');
    navigate('/login'); // Redirect to login page after logout
  };

  return (
    <>
    <motion.div 
        className="fixed top-0 left-0 right-0 h-1 bg-blue-600 z-50 origin-left"
        style={{ scaleX: smoothProgress }}
      />

      
      <nav className="fixed top-0 left-0 right-0 bg-white shadow-lg z-40">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-2xl font-bold text-blue-600"
          >
            PG Finder
          </motion.h1>
          <div className="hidden md:flex space-x-4 items-center">
            <Link to="/" className="text-gray-600 hover:text-blue-600">Home</Link>
            <Link to="#about" className="text-gray-600 hover:text-blue-600">About</Link>
            <Link to="/#services" className="text-gray-600 hover:text-blue-600">Services</Link>
            <Link to="/#contact" className="text-gray-600 hover:text-blue-600">Contact</Link>
            {isLoggedIn ? (
              <>
                <span className="text-gray-600 hover:text-blue-600">Hi, {username}</span>
                <button
                  onClick={handleLogout}
                  className="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors duration-300"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login">
                  <button className="px-6 py-2 text-blue-600 border border-blue-600 rounded-full hover:bg-blue-600 hover:text-white transition-colors duration-300">Login</button>
                </Link>
                <Link to="/signup">
                  <button className="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors duration-300">Sign Up</button>
                </Link>
              </>
            )}
          </div>
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="text-blue-600" /> : <Menu className="text-blue-600" />}
          </button>
        </div>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="md:hidden bg-white"
          >
            <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
                <Link to="/" className="text-gray-600 hover:text-blue-600">Home</Link>
                <Link to="/#about" className="text-gray-600 hover:text-blue-600">About</Link>
                <Link to="/#services" className="text-gray-600 hover:text-blue-600">Services</Link>
                <Link to="/#contact" className="text-gray-600 hover:text-blue-600">Contact</Link>
                {isLoggedIn ? (
                <>
                  <span className="text-gray-600 hover:text-blue-600">Hi, {username}</span>
                  <button
                    onClick={handleLogout}
                    className="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors duration-300"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login">
                    <button className="px-6 py-2 text-blue-600 border border-blue-600 rounded-full hover:bg-blue-600 hover:text-white transition-colors duration-300">Login</button>
                  </Link>
                  <Link to="/signup">
                    <button className="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors duration-300">Sign Up</button>
                  </Link>
                </>
              )}
            </div>
          </motion.div>
        )}
      </nav>
      
    </>
  )
}

export default Navbar

