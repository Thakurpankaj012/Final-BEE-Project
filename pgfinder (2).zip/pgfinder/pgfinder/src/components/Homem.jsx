


'use client'

import React, { useState, useEffect, useRef } from 'react'
import { motion, useScroll, useTransform, useSpring, useInView } from 'framer-motion'
import { Menu, X, Search, Check, ChevronLeft, ChevronRight, Star, Phone, MapPin, Home, DollarSign, Users, Coffee } from 'lucide-react'
import CountUp from 'react-countup'
import axios from 'axios';
import { Link } from 'react-router-dom';
import a1 from "../assets/images/a1.jpg";
import a2 from "../assets/images/a2.jpg";
import a3 from "../assets/images/a3.jpg";
import a4 from "../assets/images/a4.jpg";
import a5 from "../assets/images/a5.jpg";
import a6 from "../assets/images/a6.jpg";

const Homem = () => {
  
  const [activeSlide, setActiveSlide] = useState(0)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [filterPrice, setFilterPrice] = useState('all')
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedPG, setSelectedPG] = useState(null)
  const [pgs, setPgs] = useState([]);
  const scrollRef = useRef(null)
  const aboutRef = useRef(null)
  const isAboutInView = useInView(aboutRef, { once: true })

  useEffect(() => {
    fetchPGs();
  }, []);

  const fetchPGs = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/pgs');
      setPgs(response.data);
    } catch (error) {
      console.error('Error fetching PGs:', error);
    }
  };



  const { scrollYProgress } = useScroll({
    target: scrollRef,
    offset: ["start start", "end end"]
  })


  const heroSlides = [
    { bg: a3, title: "Find Your Dream PG", subtitle: "Discover comfort in every corner of the city" },
    { bg: a5, title: "Verified Listings Only", subtitle: "Your safety and satisfaction, our top priority" },
    { bg: a6, title: "Instant Booking", subtitle: "Secure your stay with just a few clicks" },
  ]

  const pgListings = [
    { id: 1, name: "Luxury Loft PG", place: "Downtown", owner: "John Doe", price: 500, status: "available", phone: "+1234567890", image: "/pg1.jpg", amenities: ["Wi-Fi", "AC", "Gym"] },
    { id: 2, name: "Cozy Corner Suite", place: "Suburb", owner: "Jane Smith", price: 300, status: "unavailable", phone: "+1987654321", image: "/pg2.jpg", amenities: ["Wi-Fi", "Laundry"] },
    { id: 3, name: "Urban Nest Deluxe", place: "City Center", owner: "Mike Johnson", price: 450, status: "available", phone: "+1122334455", image: "/pg3.jpg", amenities: ["Wi-Fi", "AC", "Pool"] },
    { id: 4, name: "Serene Stay Premium", place: "Lakeside", owner: "Emily Brown", price: 600, status: "available", phone: "+1555666777", image: "/pg4.jpg", amenities: ["Wi-Fi", "AC", "Gym", "Pool"] },
    { id: 5, name: "Metro Living Basic", place: "Downtown", owner: "Chris Wilson", price: 250, status: "unavailable", phone: "+1999888777", image: "/pg5.jpg", amenities: ["Wi-Fi"] },
    { id: 6, name: "Green View Comfort", place: "Suburb", owner: "Sarah Davis", price: 350, status: "available", phone: "+1444333222", image: "/pg6.jpg", amenities: ["Wi-Fi", "AC", "Garden"] },
  ]

  const testimonials = [
    { id: 1, name: "Alice Johnson", text: "PG Finder made my relocation stress-free. Found a great PG in just a day!", rating: 5, image: "/user1.jpg" },
    { id: 2, name: "Bob Smith", text: "The verified listings gave me peace of mind. Highly recommend this platform!", rating: 4, image: "/user2.jpg" },
    { id: 3, name: "Carol White", text: "From search to booking, everything was smooth. Thank you, PG Finder!", rating: 5, image: "/user3.jpg" },
    { id: 4, name: "David Brown", text: "Great filters and search options. Found exactly what I was looking for!", rating: 5, image: "/user4.jpg" },
  ]
  const smoothProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 })


  const [activeTestimonial, setActiveTestimonial] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % heroSlides.length)
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const filteredPGs = pgs.filter(pg => 
    pg.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
    (filterStatus === 'all' || pg.status === filterStatus) &&
    (filterPrice === 'all' || 
     (filterPrice === 'low' && pg.price <= 300) ||
     (filterPrice === 'medium' && pg.price > 300 && pg.price <= 500) ||
     (filterPrice === 'high' && pg.price > 500))
  )

  const paginatedPGs = filteredPGs.slice((currentPage - 1) * 5, currentPage * 5)

  const parallaxY = useTransform(smoothProgress, [0, 1], ["0%", "50%"])

  return (
    <div ref={scrollRef} className="relative min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative h-screen">
      {heroSlides.map((slide, index) => (
        <motion.div
          key={index}
          className="absolute inset-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: index === activeSlide ? 1 : 0 }}
          transition={{ duration: 1 }}
        >
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${slide.bg})` }}
          />
          <div className="absolute inset-0 bg-black bg-opacity-50" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white">
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.5 }}
                className="text-5xl md:text-7xl font-bold mb-4"
              >
                {slide.title}
              </motion.h2>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7, duration: 0.5 }}
                className="text-xl md:text-2xl mb-8"
              >
                {slide.subtitle}
              </motion.p>
              <motion.button
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9, duration: 0.5 }}
                className="px-8 py-3 bg-blue-600 text-white rounded-full text-lg font-semibold hover:bg-blue-700 transition-colors duration-300"
              >
                Start Your Search
              </motion.button>
            </div>
          </div>
        </motion.div>
      ))}
      </section>

    
      <section ref={aboutRef}  id="about"className="py-20 bg-white overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div 
              className="md:w-1/2 mb-10 md:mb-0"
              initial={{ opacity: 0, x: -50 }}
              animate={isAboutInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-gray-800">Discover Your Ideal PG</h2>
              <p className="text-gray-600 mb-8 text-lg">We're revolutionizing the way you find and book paying guest accommodations. With our curated listings and advanced search features, finding your perfect home away from home has never been easier.</p>
              <ul className="space-y-4">
                {['Verified listings for your peace of mind', 'Instant booking feature', '24/7 customer support', 'Virtual tours available'].map((point, index) => (
                  <motion.li 
                    key={index} 
                    className="flex items-center text-gray-700 text-lg"
                    initial={{ opacity: 0, x: -20 }}
                    animate={isAboutInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                  >
                    <Check className="text-green-500 mr-2" size={24} />
                    {point}
                  </motion.li>
                ))}
              </ul>
            </motion.div>
            <div className="md:w-1/2 relative h-[400px] md:h-[600px]">
              <motion.img
                src={a4}
                alt="PG Living"
                className="absolute top-0 left-0 w-2/3 h-2/3 rounded-lg shadow-xl object-cover"
                initial={{ opacity: 0, y: 50, rotateY: 0 }}
                animate={isAboutInView ? { opacity: 1, y: 0, rotateY: -10 } : {}}
                transition={{ duration: 0.5 }}
                style={{ transformStyle: "preserve-3d" }}
              />
              <motion.img
                src={a1}
                alt="PG Amenities"
                className="absolute bottom-0 right-0 w-2/3 h-2/3 rounded-lg shadow-xl object-cover"
                initial={{ opacity: 0, y: 50, rotateY: 0 }}
                animate={isAboutInView ? { opacity: 1, y: 0, rotateY: 10 } : {}}
                transition={{ delay: 0.2, duration: 0.5 }}
                style={{ transformStyle: "preserve-3d" }}
              />
            </div>
          </div>
        </div>
      </section>

      
      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { icon: Home, label: "PGs Listed", value: 5000 },
              { icon: Users, label: "Happy Residents", value: 10000 },
              { icon: MapPin, label: "Cities Covered", value: 50 },
              { icon: Coffee, label: "Cups of Coffee", value: 25000 },
            ].map((stat, index) => (
              <motion.div
                key={index}
                className="flex flex-col items-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <stat.icon size={48} className="mb-4" />
                <CountUp
                  end={stat.value}
                  duration={2.5}
                  separator=","
                  className="text-4xl md:text-5xl font-bold mb-2"
                />
                <p className="text-lg">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      
      <section className="py-20 bg-gray-100">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold mb-10 text-center text-gray-800">Explore Our PG Listings</h2>
          <div className="mb-8 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="relative w-full md:w-auto">
              <input
                type="text"
                placeholder="Search PGs..."
                className="w-full md:w-64 pl-10 pr-4 py-2 border-2 border-gray-300 rounded-full focus:outline-none focus:border-blue-500 transition-colors duration-300"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
            <div className="flex space-x-4">
              <select
                className="px-4 py-2 border-2 border-gray-300 rounded-full focus:outline-none focus:border-blue-500 transition-colors duration-300"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="all">All Status</option>
                <option value="available">Available</option>
                <option value="unavailable">Unavailable</option>
              </select>
              <select
                className="px-4 py-2 border-2 border-gray-300 rounded-full focus:outline-none focus:border-blue-500 transition-colors duration-300"
                value={filterPrice}
                onChange={(e) => setFilterPrice(e.target.value)}
              >
                <option value="all">All Prices</option>
                <option value="low">$0 - $300</option>
                <option value="medium">$301 - $500</option>
                <option value="high">$501+</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {paginatedPGs.map((pg) => (
            <motion.div
              key={pg._id}
              className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <img src={`http://localhost:5000/${pg.image}`} alt={pg.name} className="w-full h-48 object-cover" />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">{pg.name}</h3>
                <p className="text-gray-600 mb-2"><MapPin className="inline mr-1" size={16} /> {pg.place}</p>
                <p className="text-gray-600 mb-2">Owner: {pg.owner}</p>
                <p className="text-2xl font-bold mb-2 text-blue-600">${pg.price}/month</p>
                <p className={`mb-4 ${pg.status === 'available' ? 'text-green-500' : 'text-red-500'} font-semibold`}>
                  {pg.status.charAt(0).toUpperCase() + pg.status.slice(1)}
                </p>
                <div className="flex flex-wrap mb-4">
                  {pg.amenities.map((amenity, index) => (
                    <span key={index} className="bg-gray-200 text-gray-700 rounded-full px-3 py-1 text-sm mr-2 mb-2">{amenity}</span>
                  ))}
                </div>
                <div className="flex justify-between items-center">
                  <button
                    className="px-4 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors duration-300"
                    onClick={() => setSelectedPG(pg)}
                  >
                    View Details
                  </button>
                  <Link
                    to={`/booking/${pg._id}`}
                    className="px-4 py-2 bg-green-500 text-white rounded-full hover:bg-green-600 transition-colors duration-300"
                  >
                    Book Now
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
          </div>
          <div className="mt-12 flex justify-center items-center space-x-4">
            <button
              className="px-4 py-2 bg-gray-200 rounded-full hover:bg-gray-300 transition-colors duration-300 disabled:opacity-50"
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              <ChevronLeft size={24} />
            </button>
            <span className="text-lg font-semibold text-gray-700">Page {currentPage}</span>
            <button
              className="px-4 py-2 bg-gray-200 rounded-full hover:bg-gray-300 transition-colors duration-300 disabled:opacity-50"
              onClick={() => setCurrentPage(prev => prev + 1)}
              disabled={currentPage * 5 >= filteredPGs.length}
            >
              <ChevronRight size={24} />
            </button>
          </div>
        </div>
      </section>


      
      <section className="py-20 bg-gray-900 text-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div 
              className="md:w-1/2 mb-10 md:mb-0"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6">Experience Virtual Tours</h2>
              <p className="text-gray-300 mb-8 text-lg">Can't visit in person? No problem! Our cutting-edge virtual tour technology allows you to explore PGs from the comfort of your home. Get a real feel for the space before you book.</p>
              <button className="px-8 py-3 bg-blue-600 text-white rounded-full text-lg font-semibold hover:bg-blue-700 transition-colors duration-300">
                Start Virtual Tour
              </button>
            </motion.div>
            <motion.div 
              className="md:w-1/2"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <img src={a6} alt="Virtual Tour" className="rounded-lg shadow-2xl" />
            </motion.div>
          </div>
        </div>
      </section>

     
      <section className="py-20 bg-blue-600 text-white relative overflow-hidden">
        <motion.div 
          className="absolute inset-0 bg-[url('/testimonial-bg.jpg')] bg-cover bg-center"
          style={{ y: parallaxY }}
        />
        <div className="absolute inset-0 bg-blue-600 bg-opacity-80" />
        <div className="container mx-auto px-4 relative z-10">
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center">What Our Users Say</h2>
          <div className="max-w-4xl mx-auto">
            <div className="relative h-[400px]">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={testimonial.id}
                  className="absolute top-0 left-0 w-full"
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ 
                    opacity: index === activeTestimonial ? 1 : 0,
                    x: index === activeTestimonial ? 0 : 100
                  }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="bg-white bg-opacity-10 rounded-lg p-8 backdrop-blur-sm">
                    <div className="flex items-center mb-6">
                      <img src={testimonial.image} alt={testimonial.name} className="w-16 h-16 rounded-full mr-4 object-cover" />
                      <div>
                        <h3 className="text-xl font-semibold">{testimonial.name}</h3>
                        <div className="flex">
                          {[...Array(testimonial.rating)].map((_, i) => (
                            <Star key={i} className="text-yellow-400" size={16} />
                          ))}
                        </div>
                      </div>
                    </div>
                    <p className="text-lg italic">"{testimonial.text}"</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`w-3 h-3 rounded-full ${index === activeTestimonial ? 'bg-white' : 'bg-white bg-opacity-50'}`}
                onClick={() => setActiveTestimonial(index)}
              />
            ))}
          </div>
        </div>
      </section>


      
      <section className="py-20 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div 
              className="md:w-1/2 mb-10 md:mb-0"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-gray-800">Get in Touch</h2>
              <p className="text-gray-600 mb-8 text-lg">Have questions or need assistance? Our team is here to help you find the perfect PG accommodation.</p>
              <form className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-gray-700 mb-2">Your Name</label>
                  <input type="text" id="name" className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition-colors duration-300" placeholder="John Doe" />
                </div>
                <div>
                  <label htmlFor="email" className="block text-gray-700 mb-2">Your Email</label>
                  <input type="email" id="email" className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition-colors duration-300" placeholder="john@example.com" />
                </div>
                <div>
                  <label htmlFor="message" className="block text-gray-700 mb-2">Your Message</label>
                  <textarea id="message" rows="4" className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition-colors duration-300" placeholder="How can we help you?"></textarea>
                </div>
                <button className="px-8 py-3 bg-blue-600 text-white rounded-full text-lg font-semibold hover:bg-blue-700 transition-colors duration-300">Send Message</button>
              </form>
            </motion.div>
            <motion.div 
              className="md:w-1/2"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <img src={a2} alt="Contact Us" className="rounded-lg shadow-xl" />
            </motion.div>
          </div>
        </div>
      </section>


     
     
      {selectedPG && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-2xl w-full">
            <div className="flex justify-between items-start mb-4">
              <h2 className="text-2xl font-bold text-gray-800">{selectedPG.name}</h2>
              <button onClick={() => setSelectedPG(null)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            <img src={`http://localhost:5000/${selectedPG.image}`} alt={selectedPG.name} className="w-full h-64 object-cover rounded-lg mb-4" />
            <div className="grid grid-cols-2 gap-4 mb-4">
              <p className="text-gray-600"><MapPin className="inline mr-1" size={16} /> {selectedPG.place}</p>
              <p className="text-gray-600">Owner: {selectedPG.owner}</p>
              <p className="text-2xl font-bold text-blue-600">${selectedPG.price}/month</p>
              <p className={`${selectedPG.status === 'available' ? 'text-green-500' : 'text-red-500'} font-semibold`}>
                {selectedPG.status.charAt(0).toUpperCase() + selectedPG.status.slice(1)}
              </p>
            </div>
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">Amenities</h3>
              <div className="flex flex-wrap">
                {selectedPG.amenities.map((amenity, index) => (
                  <span key={index} className="bg-gray-200 text-gray-700 rounded-full px-3 py-1 text-sm mr-2 mb-2">{amenity}</span>
                ))}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <a href={`tel:${selectedPG.phone}`} className="flex items-center text-blue-600 hover:text-blue-800">
                <Phone className="mr-2" size={20} />
                {selectedPG.phone}
              </a>
              {/* <Link
                to={`/booking/${selectedPG.id}`}
                className="px-6 py-3 bg-green-500 text-white rounded-full hover:bg-green-600 transition-colors duration-300">
                Book Now
              </Link> */}
            </div>
          </div>
        </div>
      )}

    </div>
  )
}

export default Homem

