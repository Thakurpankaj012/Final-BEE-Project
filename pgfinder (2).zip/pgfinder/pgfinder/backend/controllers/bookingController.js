


const Booking = require('../models/Booking');
const { catchAsync } = require('../utils/catchAsync');

exports.createBooking = catchAsync(async (req, res) => {
  const { name, email, address, phone, date, pgDetails } = req.body;
  const idProof = req.file.path;

  const newBooking = new Booking({
    name,
    email,
    address,
    phone,
    date,
    idProof,
    pgDetails: JSON.parse(pgDetails),
    status: 'pending', 
  });

  await newBooking.save();

  res.status(201).json({
    success: true,
    message: 'Booking created successfully',
    booking: newBooking,
  });
});

exports.getAllBookings = catchAsync(async (req, res) => {
  const bookings = await Booking.find();
  res.status(200).json(bookings);
});

exports.getBookingById = catchAsync(async (req, res) => {
  const booking = await Booking.findById(req.params.id);
  if (!booking) {
    return res.status(404).json({ message: 'Booking not found' });
  }
  res.status(200).json(booking);
});

exports.updateBooking = catchAsync(async (req, res) => {
  const booking = await Booking.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!booking) {
    return res.status(404).json({ message: 'Booking not found' });
  }
  res.status(200).json(booking);
});

exports.deleteBooking = catchAsync(async (req, res) => {
  const booking = await Booking.findByIdAndDelete(req.params.id);
  if (!booking) {
    return res.status(404).json({ message: 'Booking not found' });
  }
  res.status(204).json(null);
});

