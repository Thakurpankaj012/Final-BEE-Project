const Pg = require('../models/Pg');
const { catchAsync } = require('../utils/catchAsync');

exports.createPg = catchAsync(async (req, res) => {
    const { name, place, owner, price, phone } = req.body;
    let amenities = [];
    try {
      amenities = JSON.parse(req.body.amenities);
    } catch (error) {
      console.error('Error parsing amenities:', error);
    }
  
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'Image is required' });
    }
  
    const image = req.file.path;
  
    const newPg = new Pg({
      name,
      place,
      owner,
      price: Number(price),
      phone,
      image,
      amenities,
      status: 'available', 
    });
  
    await newPg.save();
  
    res.status(201).json({
      success: true,
      message: 'PG created successfully',
      pg: newPg,
    });
  });
  
exports.getAllPgs = catchAsync(async (req, res) => {
  const pgs = await Pg.find();
  res.status(200).json(pgs);
});

exports.getPgById = catchAsync(async (req, res) => {
    const pg = await Pg.findById(req.params.id);
    if (!pg) {
      return res.status(404).json({ message: 'PG not found' });
    }
    res.status(200).json(pg);
  });
  
  exports.updatePg = catchAsync(async (req, res) => {
    const { name, place, owner, price, phone, status } = req.body;
    let amenities = [];
    try {
      amenities = JSON.parse(req.body.amenities);
    } catch (error) {
      console.error('Error parsing amenities:', error);
    }
  
    const pg = await Pg.findById(req.params.id);
    if (!pg) {
      return res.status(404).json({ message: 'PG not found' });
    }
  
    pg.name = name;
    pg.place = place;
    pg.owner = owner;
    pg.price = Number(price);
    pg.phone = phone;
    pg.status = status;
    pg.amenities = amenities;
  
    if (req.file) {
      
      if (pg.image) {
        const oldImagePath = path.join(__dirname, '..', pg.image);
        fs.unlink(oldImagePath, (err) => {
          if (err) console.error('Error deleting old image:', err);
        });
      }
      pg.image = req.file.path;
    }
  
    await pg.save();
  
    res.status(200).json({
      success: true,
      message: 'PG updated successfully',
      pg: pg,
    });
  });
  

exports.deletePg = catchAsync(async (req, res) => {
  const pg = await Pg.findByIdAndDelete(req.params.id);
  if (!pg) {
    return res.status(404).json({ message: 'PG not found' });
  }
  res.status(204).json(null);
});

