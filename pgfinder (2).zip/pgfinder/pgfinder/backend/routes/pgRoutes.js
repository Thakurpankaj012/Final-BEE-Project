

const express = require('express');
const multer = require('multer');
const path = require('path');
const { createPg, getAllPgs, getPgById, updatePg, deletePg } = require('../controllers/pgController');

const router = express.Router();


const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });


router.post('/', upload.single('image'), createPg);


router.get('/', getAllPgs);


router.get('/:id', getPgById);


router.patch('/:id', upload.single('image'), updatePg);


router.delete('/:id', deletePg);

module.exports = router;

