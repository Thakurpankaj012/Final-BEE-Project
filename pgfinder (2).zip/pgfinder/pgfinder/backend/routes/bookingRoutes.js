

const express = require('express');
const multer = require('multer');
const path = require('path');
const { createBooking, getAllBookings, getBookingById, updateBooking, deleteBooking } = require('../controllers/bookingController');

const router = express.Router();


const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });


router.post('/', upload.single('idProof'), createBooking);


router.get('/', getAllBookings);


router.get('/:id', getBookingById);


router.patch('/:id', updateBooking);


router.delete('/:id', deleteBooking);

module.exports = router;

